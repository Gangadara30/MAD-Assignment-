package com.example.verifyphone;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class successPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success_page);

    }
    }
